import numpy as np
import yfinance as yf
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import SimpleRNN, LSTM, GRU, Dense

d = yf.download("GOOGL", "2020-04-01", "2023-04-01")['Open']

n = int(len(d) * .8)
s = MinMaxScaler()
tr = s.fit_transform(d[:n].values.reshape(-1,1))
te = s.transform(d[n:].values.reshape(-1,1))

def seq(x):
    X = [x[i-50:i] for i in range(50, len(x))]
    return np.array(X), x[50:]

X, y = seq(tr)
Xt, yt = seq(te)

for R in [SimpleRNN, LSTM, GRU]:
    m = Sequential([R(50, input_shape=(50,1)), Dense(1)])
    m.compile('adam', 'mse')
    m.fit(X, y, epochs=3, batch_size=2, verbose=0)
    p = s.inverse_transform(m.predict(Xt, verbose=0))
    plt.plot(p, label=R.__name__)

plt.plot(d[n:].values, label='Actual')
plt.legend()
plt.show()
