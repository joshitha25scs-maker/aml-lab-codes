import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.datasets import imdb
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, SimpleRNN, Dropout, Dense

(x1, y1), (x2, y2) = imdb.load_data(num_words=20000)

x1 = pad_sequences(x1, maxlen=100, dtype='int32')
x2 = pad_sequences(x2, maxlen=100, dtype='int32')
y1 = np.asarray(y1, dtype='float32')
y2 = np.asarray(y2, dtype='float32')

m = Sequential([
    Embedding(20000, 128),
    SimpleRNN(128),
    Dropout(.4),
    Dense(1, activation='sigmoid')
])

m.compile(optimizer='adam',
          loss='binary_crossentropy',
          metrics=['accuracy'])

h = m.fit(x1, y1, epochs=3, batch_size=32,
          validation_data=(x2, y2))

print("Accuracy:", h.history['accuracy'])
print("Loss:", h.history['loss'])
print("Validation Accuracy:", h.history['val_accuracy'])
print("Validation Loss:", h.history['val_loss'])

plt.plot(h.history['accuracy'])
plt.plot(h.history['val_accuracy'])
plt.legend(['Training', 'Validation'])
plt.show()
