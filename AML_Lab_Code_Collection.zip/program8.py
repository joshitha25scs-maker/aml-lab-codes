import tensorflow as tf
from tensorflow.keras.layers import Dense, Flatten, Reshape, LeakyReLU
from tensorflow.keras.models import Sequential
import numpy as np
import matplotlib.pyplot as plt

(train_images, train_labels), (_, _) = tf.keras.datasets.mnist.load_data()
train_images = train_images / 255.0
train_images = train_images.reshape(train_images.shape[0], 28, 28, 1).astype('float32')

def build_generator():
    model = Sequential()
    model.add(Dense(256, input_dim=100))
    model.add(LeakyReLU(negative_slope=0.2))
    model.add(Dense(512))
    model.add(LeakyReLU(negative_slope=0.2))
    model.add(Dense(1024))
    model.add(LeakyReLU(negative_slope=0.2))
    model.add(Dense(28 * 28 * 1, activation='tanh'))
    model.add(Reshape((28, 28, 1)))
    return model

def build_discriminator():
    model = Sequential()
    model.add(Flatten(input_shape=(28, 28, 1)))
    model.add(Dense(512))
    model.add(LeakyReLU(negative_slope=0.2))
    model.add(Dense(256))
    model.add(LeakyReLU(negative_slope=0.2))
    model.add(Dense(1, activation='sigmoid'))
    return model

generator = build_generator()
discriminator = build_discriminator()

discriminator.compile(
    loss='binary_crossentropy',
    optimizer='adam',
    metrics=['accuracy']
)

discriminator.trainable = False

gan = Sequential([generator, discriminator])
gan.compile(loss='binary_crossentropy', optimizer='adam')

def train_gan(gan, dataset, batch_size, epochs):
    discriminator.trainable = True

    for epoch in range(epochs):
        for _ in range(batch_size):
            noise = np.random.normal(0, 1, (batch_size, 100))
            fake_images = generator.predict(noise, verbose=0)
            real_images = dataset[np.random.randint(0, dataset.shape[0], batch_size)]

            labels_real = np.ones((batch_size, 1))
            labels_fake = np.zeros((batch_size, 1))

            discriminator.train_on_batch(real_images, labels_real)
            discriminator.train_on_batch(fake_images, labels_fake)

        discriminator.trainable = False
        noise = np.random.normal(0, 1, (batch_size, 100))
        labels_gan = np.ones((batch_size, 1))
        gan.train_on_batch(noise, labels_gan)

        if epoch % 100 == 0:
            print(f'Epoch {epoch} completed')

train_gan(gan, train_images, batch_size=32, epochs=10)

def generate_and_plot_images(generator, num_images):
    noise = np.random.normal(0, 1, (num_images, 100))
    generated_images = generator.predict(noise, verbose=0)
    generated_images = generated_images.reshape(generated_images.shape[0], 28, 28)

    plt.figure(figsize=(10, 10))
    for i in range(num_images):
        plt.subplot(5, 5, i+1)
        plt.imshow(generated_images[i], cmap='gray')
        plt.axis('off')
    plt.show()

generate_and_plot_images(generator, 25)
