AML LAB CODE COLLECTION

Program 1 - CNN MNIST Classification
Program 2 - Heart Disease Classification
Program 3 - K-Means Customer Clustering
Program 4 - RNN IMDB Sentiment Classification
Program 5 - No program
Program 6 - RNN IMDB Sentiment Classification
Program 7 - Stock Price Prediction using SimpleRNN, LSTM and GRU
Program 8 - GAN MNIST Image Generation

Program 2 needs heart.csv.
Program 3 needs Customer_Behaviour.csv.
Program 7 needs internet access for yfinance.
