import pandas as pd
from google.colab import files
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score

files.upload()
data = pd.read_csv("heart.csv")

print("Dataset Shape:", data.shape)
data.info()
print(data.head())

X = data.drop("target", axis=1)
Y = data["target"]

print(X)
print(Y)

Xtr, Xte, Ytr, Yte = train_test_split(
    X, Y, test_size=.2, stratify=Y, random_state=2
)

lr = LogisticRegression(max_iter=1000)
lr.fit(Xtr, Ytr)
print("Logistic Regression:", accuracy_score(Yte, lr.predict(Xte)))

dt = DecisionTreeClassifier(random_state=2)
dt.fit(Xtr, Ytr)
print("Decision Tree:", accuracy_score(Yte, dt.predict(Xte)))
