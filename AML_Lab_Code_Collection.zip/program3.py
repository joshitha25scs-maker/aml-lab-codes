import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from sklearn.cluster import KMeans
from google.colab import files

data_to_load = files.upload()
data = pd.read_csv('Customer_Behaviour.csv')
print(data.head())

X = data.loc[:, ['EstimatedSalary', 'Purchased']].values

kmeans = KMeans(n_clusters=5, init='k-means++', random_state=42)
label = kmeans.fit_predict(X)

print(label)
print(kmeans.cluster_centers_)

plt.figure(figsize=(8,8))
plt.scatter(X[label == 0,0], X[label == 0,1], s=50, c='green', label='Cluster 1')
plt.scatter(X[label == 1,0], X[label == 1,1], s=50, c='yellow', label='Cluster 2')
plt.scatter(X[label == 2,0], X[label == 2,1], s=50, c='red', label='Cluster 3')
plt.scatter(X[label == 3,0], X[label == 3,1], s=50, c='purple', label='Cluster 4')
plt.scatter(X[label == 4,0], X[label == 4,1], s=50, c='blue', label='Cluster 5')
plt.scatter(kmeans.cluster_centers_[:,0],
            kmeans.cluster_centers_[:,1],
            s=100, c='black', marker='*', label='Centroids')

plt.title('User_ID')
plt.xlabel('Estimated Salary')
plt.ylabel('Purchased')
plt.legend()
plt.show()
